//
//  Konstant.h
//  Mazegame1_0
//
//  Created by Stijn on 22/12/2018.
//

#ifndef Konstant_h
#define Konstant_h


#define MAZE_SIZE 600
#define GRID_SIZE 15

#define GRID_ELEMENT_SIZE ((float)MAZE_SIZE / GRID_SIZE)



#endif /* Konstant_h */
